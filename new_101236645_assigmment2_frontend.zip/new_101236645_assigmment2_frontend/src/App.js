
import React, {Component} from 'react';
import axios from 'axios'
import {Link} from 'react-router-dom';
import './App.css';
import { Navbar, Container, Nav, Button } from 'react'


export default class App extends Component
{
  
  constructor(props)
  {
    super(props);

    this.state=
    {
      employees: [],
      employee: [],
      email: '',
      firstName: '',
      lastName: '',

    }
  }


    addEmployee()
    {
      axios.post(`http://localhost:9090/api/v1/employees`, {
        firstName: this.state.firstName,
        lastName: this.state.lastName,
        email: this.state.email
    }).then(res =>{
        console.log(res.data);
    })
    }

    updateEmployee()
    {
      axios.put(`http://localhost:9090/api/v1/employees/id`, {
        firstName: this.state.firstName,
        lastName: this.state.lastName,
        email: this.state.email
    }).then(res =>{
        console.log(res.data);
    })
    }
    

  



render()
{
  return (
    <div class="container">
			
			<div class="st-container" >
			
				<input type="radio" name="radio-set" checked="checked" id="st-control-1"/>
				<a href="#st-panel-1">Home Page</a>
				<input type="radio" name="radio-set" id="st-control-2"/>
				<a href="#st-panel-2">Add Employee</a>
				<input type="radio" name="radio-set" id="st-control-3"/>
				<a href="#st-panel-3">Update Employee</a>
				<input type="radio" name="radio-set" id="st-control-4"/>
				<a href="#st-panel-4">View Employee</a>
				<input type="radio" name="radio-set" id="st-control-5"/>
				<a href="#st-panel-5">Delete Employee</a>
				
				<div class="st-scroll">
				
					
					<section class="st-panel" id="st-panel-1">
            <div class="st-deco" data-icon="&#xf069;"></div>
						<h2>Welcome to Robbi's Employee Manager</h2>
						<p>Fulfilling your employee needs!</p>
					</section>
					
					<section class="st-panel st-color" id="st-panel-2">
						<div class="st-deco" data-icon="&#xf118;"></div>
						<h2>Add Employee</h2>

            <div class="container">
	<div class="card">
		<div class="card-image">	
		
		</div>

    <div class="middle">
    <form class="card-form" onSubmit={()=>
    {
        this.addEmployee();
    }}>
			      <label>First Name:</label><br/>
            <input name="firstName"  type="text" ></input><br/>

            <label>Last Name:</label><br/>
            <input name="lastName"  type="text" ></input><br/>

            <label>Email Id:</label><br/>
            <input name="email" placeholder="Enter a valid email address" type="email"></input><br/>
            <br/>

            <input type="submit" value="Save"></input>

		</form>
    </div>
		
		
	</div>
</div>


					</section>
					
					<section class="st-panel" id="st-panel-3">
						<div class="st-deco" data-icon="&#xf0f4;"></div>
						<h2>Update Employee</h2>


            <form class="card-form"  onSubmit={()=>
    {
        this.updateEmployee();
    }}>

<div  class="middle">
      <label>First Name:</label><br/>
            <input name="firstName"  type="text" ></input><br/>

            <label>Last Name:</label><br/>
            <input name="lastName"  type="text" ></input><br/>

            <label>Email Id:</label><br/>
            <input name="email" placeholder="Enter a valid email address" type="email"></input><br/>
            <br/>
            <input type="submit" value="Update"></input>
      </div>
			      

		</form>

					</section>
					
					<section class="st-panel st-color" id="st-panel-4">
						<div class="st-deco" data-icon="&#xf06c;"></div>
						<h2>View Employee</h2>

<div  class="middle">
<h1>Employee First Name: </h1>
          <h1>Employee Last Name: </h1>
          <h1>Employee Email: </h1>
</div>
         

          <div>

          {this.state.employees.map(e => (
            <h1>{e.firstName}</h1>
          )) }
          </div>


            
              
            

					</section>
					
					<section class="st-panel" id="st-panel-5">
						<div class="st-deco" data-icon="&#xf004;"></div>
						<h2>Delete Employee</h2>


              <div class="middle">
              <input type="submit" value="DELETE" class="red"></input>
              </div>
            
					</section>

				</div>
				
			</div>
			
</div>
  )
}

}

